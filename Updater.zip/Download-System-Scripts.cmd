@echo off
setlocal

title MyDashboard - Download System Scripts

set "SCRIPT=%~dp0MyDashboardUpdate.ps1"

if not exist "%SCRIPT%" (
    echo.
    echo ERROR: MyDashboardUpdate.ps1 was not found.
    echo.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   MyDashboard Recursive Update
echo ============================================
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"

set "EXITCODE=%ERRORLEVEL%"

echo.

if "%EXITCODE%"=="0" (
    echo Update completed successfully.
) else (
    echo Update failed with exit code %EXITCODE%.
)

echo.
pause

exit /b %EXITCODE%
