﻿# MyDashboardProtocol.ps1

$ErrorActionPreference = "Stop"

$InstallRoot = "C:\MyDashboard"
$Log = Join-Path $InstallRoot "Protocol.log"

function Write-Log {
    param([string]$Message)

    Add-Content `
        -LiteralPath $Log `
        -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $Message"
}

try {

    New-Item `
        -ItemType Directory `
        -Path $InstallRoot `
        -Force `
        | Out-Null

    $uri =
        if ($args.Count -gt 0) {
            [string]$args[0]
        }
        else {
            ""
        }

    $uri =
        $uri.Trim().Trim('"').Trim("'").ToLower()

    if ($uri.StartsWith("mydashboard://")) {

        $command = $uri.Substring(14)

    }
    else {

        $command = $uri
    }

    $command = $command.Trim("/").Trim()

    Write-Log "URI=[$uri] COMMAND=[$command]"

    $powershell =
        "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"


    if ($command -eq "setup") {

        $script =
            Join-Path $InstallRoot "MyDashboardUpdate.ps1"

        if (!(Test-Path -LiteralPath $script)) {

            Write-Log "ERROR: MyDashboardUpdate.ps1 not found."

            exit 1
        }

        Write-Log "Starting recursive MyDashboard update."

        Start-Process `
            -FilePath $powershell `
            -WorkingDirectory $InstallRoot `
            -ArgumentList @(
                "-NoLogo",
                "-NoProfile",
                "-ExecutionPolicy", "Bypass",
                "-File", $script
            )

        Write-Log "MyDashboard update process started."

        exit 0
    }


    if (
        $command -eq "idprinting" -or
        $command -eq "deliverynote"
    ) {

        $launcher =
            Join-Path $InstallRoot "MyDashboardLauncher.ps1"

        if (!(Test-Path -LiteralPath $launcher)) {

            Write-Log "ERROR: MyDashboardLauncher.ps1 not found."

            exit 1
        }

        Write-Log "Starting launcher: $command"

        Start-Process `
            -FilePath $powershell `
            -WorkingDirectory $InstallRoot `
            -ArgumentList @(
                "-NoLogo",
                "-NoProfile",
                "-ExecutionPolicy", "Bypass",
                "-File", $launcher,
                $command
            )

        Write-Log "Launcher started: $command"

        exit 0
    }


    Write-Log "ERROR: Unknown command [$command]"

    exit 1

}
catch {

    Write-Log "FATAL ERROR: $($_.Exception.Message)"

    exit 1
}
