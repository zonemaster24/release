# =========================================================
# MyDashboardSetup.ps1
#
# FIRST-TIME INSTALLER
#
# This script:
#   1. Creates C:\MyDashboard
#   2. Downloads the complete MyDashboard package
#      using the existing MyDashboardUpdate.ps1
#   3. Runs Download-System-Scripts.cmd if present
#   4. Registers mydashboard://
#   5. Creates the protocol handler
#   6. Finishes the installation
#
# After this runs once, the MyDashboard buttons can use:
#
#   mydashboard://studentid
#   mydashboard://pickupcard
#   mydashboard://employeeid
#   mydashboard://requestform
#   mydashboard://deliverynote
#   mydashboard://idprinting
# =========================================================

$ErrorActionPreference = "Stop"

# =========================================================
# SETTINGS
# =========================================================

$InstallRoot = "C:\MyDashboard"

$PowerShell = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"

$LogFile = Join-Path `
    $InstallRoot `
    "MyDashboardSetup.log"


# =========================================================
# CREATE INSTALL DIRECTORY
# =========================================================

if (!(Test-Path -LiteralPath $InstallRoot)) {

    New-Item `
        -ItemType Directory `
        -Path $InstallRoot `
        -Force |
        Out-Null
}


# =========================================================
# LOGGING
# =========================================================

function Write-Log {

    param(
        [string]$Message
    )

    try {

        Add-Content `
            -LiteralPath $LogFile `
            -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $Message"

    }
    catch {
    }
}


Write-Log "============================================================"
Write-Log "MyDashboard Setup Started"
Write-Log "============================================================"


# =========================================================
# SHOW MESSAGE
# =========================================================

function Show-Info {

    param(
        [string]$Message
    )

    Write-Host ""
    Write-Host $Message -ForegroundColor Cyan
    Write-Host ""
}


# =========================================================
# CHECK ADMIN
# =========================================================

$CurrentIdentity =
    [Security.Principal.WindowsIdentity]::GetCurrent()

$Principal =
    New-Object Security.Principal.WindowsPrincipal(
        $CurrentIdentity
    )

$IsAdmin =
    $Principal.IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator
    )


# =========================================================
# AUTO-ELEVATE
# =========================================================

if (!$IsAdmin) {

    Write-Log "Not running as Administrator."

    Write-Log "Requesting Administrator elevation."

    try {

        $Arguments = @(
            "-NoLogo"
            "-NoProfile"
            "-ExecutionPolicy"
            "Bypass"
            "-File"
            "`"$PSCommandPath`""
        )

        Start-Process `
            -FilePath $PowerShell `
            -ArgumentList $Arguments `
            -Verb RunAs

        Write-Log "Elevation requested."

        exit 0

    }
    catch {

        Write-Log `
            "ERROR: Unable to request Administrator elevation."

        Write-Log `
            $_.Exception.Message

        exit 1
    }
}


Write-Log "Running with Administrator privileges."


# =========================================================
# TLS
# =========================================================

try {

    [Net.ServicePointManager]::SecurityProtocol =
        [Net.SecurityProtocolType]::Tls12

}
catch {
}


# =========================================================
# CHECK FOR EXISTING MYDASHBOARD
# =========================================================

$UpdateScript = Join-Path `
    $InstallRoot `
    "MyDashboardUpdate.ps1"


$ProtocolScript = Join-Path `
    $InstallRoot `
    "MyDashboardProtocol.ps1"


$LauncherScript = Join-Path `
    $InstallRoot `
    "MyDashboardLauncher.ps1"


$DownloadCmd = Join-Path `
    $InstallRoot `
    "Download-System-Scripts.cmd"


Write-Log "Checking existing MyDashboard installation."


# =========================================================
# IF UPDATE SCRIPT DOES NOT EXIST
# =========================================================

if (!(Test-Path -LiteralPath $UpdateScript)) {

    Write-Log "MyDashboardUpdate.ps1 not found."

    Write-Log `
        "The setup package must contain MyDashboardUpdate.ps1."

    Show-Info `
        "MyDashboardUpdate.ps1 was not found in C:\MyDashboard."

    Write-Host `
        "The setup package is incomplete." `
        -ForegroundColor Red

    exit 1
}


# =========================================================
# RUN EXISTING UPDATE SCRIPT
# =========================================================

Show-Info `
    "Downloading MyDashboard..."

Write-Log `
    "Starting MyDashboardUpdate.ps1."


try {

    $UpdateProcess =
        Start-Process `
            -FilePath $PowerShell `
            -WorkingDirectory $InstallRoot `
            -ArgumentList @(
                "-NoLogo"
                "-NoProfile"
                "-ExecutionPolicy"
                "Bypass"
                "-File"
                "`"$UpdateScript`""
            ) `
            -Wait `
            -PassThru


    Write-Log `
        "MyDashboardUpdate.ps1 exit code: $($UpdateProcess.ExitCode)"


    if ($UpdateProcess.ExitCode -ne 0) {

        throw `
            "MyDashboardUpdate.ps1 failed with exit code $($UpdateProcess.ExitCode)."
    }

}
catch {

    Write-Log `
        "UPDATE ERROR: $($_.Exception.Message)"

    Write-Host ""
    Write-Host `
        "MyDashboard download failed." `
        -ForegroundColor Red

    Write-Host `
        $_.Exception.Message `
        -ForegroundColor Red

    exit 1
}


# =========================================================
# VERIFY FILES
# =========================================================

Write-Log "Checking installed files."


$RequiredFiles = @(
    "MyDashboardUpdate.ps1"
    "MyDashboardProtocol.ps1"
    "MyDashboardLauncher.ps1"
)


foreach ($RequiredFile in $RequiredFiles) {

    $RequiredPath =
        Join-Path `
            $InstallRoot `
            $RequiredFile


    if (!(Test-Path -LiteralPath $RequiredPath)) {

        Write-Log `
            "WARNING: Missing $RequiredFile"

    }
    else {

        Write-Log `
            "Found $RequiredFile"
    }
}


# =========================================================
# RUN DOWNLOAD-SYSTEM-SCRIPTS.CMD
# =========================================================

if (Test-Path -LiteralPath $DownloadCmd) {

    Show-Info `
        "Running MyDashboard system setup..."

    Write-Log `
        "Starting Download-System-Scripts.cmd."


    try {

        $CmdProcess =
            Start-Process `
                -FilePath $DownloadCmd `
                -WorkingDirectory $InstallRoot `
                -Wait `
                -PassThru


        Write-Log `
            "Download-System-Scripts.cmd exit code: $($CmdProcess.ExitCode)"


        if ($CmdProcess.ExitCode -ne 0) {

            Write-Log `
                "WARNING: Download-System-Scripts.cmd returned non-zero exit code."
        }

    }
    catch {

        Write-Log `
            "CMD ERROR: $($_.Exception.Message)"
    }

}
else {

    Write-Log `
        "Download-System-Scripts.cmd not found."

    Write-Log `
        "Continuing without CMD."
}


# =========================================================
# REGISTER MYDASHBOARD PROTOCOL
# =========================================================

Show-Info `
    "Registering MyDashboard..."

Write-Log `
    "Registering mydashboard:// protocol."


$ProtocolRoot =
    "HKCU:\Software\Classes\mydashboard"


$ProtocolCommand =
    "$ProtocolRoot\shell\open\command"


try {

    # -----------------------------------------------------
    # Create protocol root
    # -----------------------------------------------------

    New-Item `
        -Path $ProtocolRoot `
        -Force |
        Out-Null


    # -----------------------------------------------------
    # Protocol information
    # -----------------------------------------------------

    New-ItemProperty `
        -Path $ProtocolRoot `
        -Name "URL Protocol" `
        -Value "" `
        -PropertyType String `
        -Force |
        Out-Null


    Set-ItemProperty `
        -Path $ProtocolRoot `
        -Name "(default)" `
        -Value "URL:MyDashboard Protocol"


    # -----------------------------------------------------
    # Create shell/open/command
    # -----------------------------------------------------

    New-Item `
        -Path "$ProtocolRoot\shell" `
        -Force |
        Out-Null


    New-Item `
        -Path "$ProtocolRoot\shell\open" `
        -Force |
        Out-Null


    New-Item `
        -Path $ProtocolCommand `
        -Force |
        Out-Null


    # -----------------------------------------------------
    # Protocol command
    # -----------------------------------------------------

    $CommandValue =
        "`"$PowerShell`" " +
        "-NoLogo " +
        "-NoProfile " +
        "-ExecutionPolicy Bypass " +
        "-File `"$ProtocolScript`" " +
        "`"%1`""


    Set-ItemProperty `
        -Path $ProtocolCommand `
        -Name "(default)" `
        -Value $CommandValue


    Write-Log `
        "mydashboard:// protocol registered."

}
catch {

    Write-Log `
        "PROTOCOL REGISTRATION ERROR: $($_.Exception.Message)"

    Write-Host ""
    Write-Host `
        "Protocol registration failed." `
        -ForegroundColor Red

    Write-Host `
        $_.Exception.Message `
        -ForegroundColor Red

    exit 1
}


# =========================================================
# VERIFY PROTOCOL REGISTRATION
# =========================================================

try {

    $RegisteredCommand =
        Get-ItemPropertyValue `
            -Path $ProtocolCommand `
            -Name "(default)"


    Write-Log `
        "Registered command: $RegisteredCommand"

}
catch {

    Write-Log `
        "WARNING: Could not verify protocol registration."
}


# =========================================================
# UNBLOCK INSTALLED POWERSHELL FILES
# =========================================================

Write-Log `
    "Removing Windows download blocking."


$FilesToUnblock = @(
    $UpdateScript
    $ProtocolScript
    $LauncherScript
    $DownloadCmd
)


foreach ($File in $FilesToUnblock) {

    if (Test-Path -LiteralPath $File) {

        try {

            Unblock-File `
                -LiteralPath $File `
                -ErrorAction SilentlyContinue

        }
        catch {
        }
    }
}


# =========================================================
# CREATE DESKTOP SHORTCUT
# =========================================================

try {

    $Desktop =
        [Environment]::GetFolderPath(
            "Desktop"
        )


    $ShortcutPath =
        Join-Path `
            $Desktop `
            "MyDashboard.lnk"


    $WshShell =
        New-Object -ComObject WScript.Shell


    $Shortcut =
        $WshShell.CreateShortcut(
            $ShortcutPath
        )


    $Shortcut.TargetPath =
        $PowerShell


    $Shortcut.Arguments =
        "-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$LauncherScript`""


    $Shortcut.WorkingDirectory =
        $InstallRoot


    $Shortcut.Description =
        "MyDashboard"


    $Shortcut.Save()


    Write-Log `
        "Desktop shortcut created."

}
catch {

    Write-Log `
        "Shortcut creation skipped: $($_.Exception.Message)"
}


# =========================================================
# FINISHED
# =========================================================

Write-Log "============================================================"
Write-Log "MyDashboard Setup Completed"
Write-Log "============================================================"


Write-Host ""
Write-Host "============================================" `
    -ForegroundColor Green

Write-Host " MyDashboard Setup Completed" `
    -ForegroundColor Green

Write-Host "============================================" `
    -ForegroundColor Green

Write-Host ""

Write-Host "Installed to:" `
    -ForegroundColor Cyan

Write-Host $InstallRoot `
    -ForegroundColor White

Write-Host ""

Write-Host "Protocol:" `
    -ForegroundColor Cyan

Write-Host "mydashboard://" `
    -ForegroundColor White

Write-Host ""

Write-Host "You can now use the MyDashboard buttons." `
    -ForegroundColor Green

Write-Host ""


# =========================================================
# OPTIONAL: OPEN DASHBOARD
# =========================================================

# Uncomment this if you want the setup program
# to automatically open your Google Apps Script dashboard.

# Start-Process "YOUR_MYDASHBOARD_WEB_APP_URL"


exit 0