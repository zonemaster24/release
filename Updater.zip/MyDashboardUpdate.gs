const MYDASHBOARD_FOLDER_ID = '1rXGsXlDcVaPdT0OXtYDsFrzLH88FXKJk';

function doGet(e) {
  try {
    const action = e && e.parameter ? e.parameter.action : '';

    if (action !== 'download') {
      return json_({
        ok: true,
        service: 'MyDashboard updater',
        message: 'Use ?action=download'
      });
    }

    const root = DriveApp.getFolderById(MYDASHBOARD_FOLDER_ID);

    const blobs = [];
    addFolderRecursive_(root, '', blobs);

    if (blobs.length === 0) {
      throw new Error('The MyDashboard Google Drive folder is empty.');
    }

    // Create the ZIP while preserving the complete folder structure.
    const zipBlob = Utilities.zip(blobs, 'MyDashboard.zip');

    // Convert the complete ZIP to Base64.
    const base64 = Utilities.base64Encode(zipBlob.getBytes());

    return json_({
      ok: true,
      fileName: 'MyDashboard.zip',
      size: zipBlob.getBytes().length,
      data: base64
    });

  } catch (err) {

    return json_({
      ok: false,
      error: String(err && err.message ? err.message : err)
    });
  }
}


/*
 * Recursively collect files from the Google Drive folder.
 *
 * Example:
 *
 * MyDashboard/
 *   MyDashboardLauncher.ps1
 *   Apps/
 *      IDPrinting.exe
 *      DeliveryNote.exe
 *   Scripts/
 *      test.ps1
 *
 * The ZIP keeps:
 *
 * Apps/IDPrinting.exe
 * Apps/DeliveryNote.exe
 * Scripts/test.ps1
 */
function addFolderRecursive_(folder, relativePath, blobs) {

  const files = folder.getFiles();

  while (files.hasNext()) {

    const file = files.next();

    const blob = file.getBlob();

    const zipPath = relativePath
      ? relativePath + '/' + file.getName()
      : file.getName();

    blob.setName(zipPath);

    blobs.push(blob);
  }


  const folders = folder.getFolders();

  while (folders.hasNext()) {

    const child = folders.next();

    const childPath = relativePath
      ? relativePath + '/' + child.getName()
      : child.getName();

    addFolderRecursive_(child, childPath, blobs);
  }
}


function json_(object) {

  return ContentService
    .createTextOutput(JSON.stringify(object))
    .setMimeType(ContentService.MimeType.JSON);
}
