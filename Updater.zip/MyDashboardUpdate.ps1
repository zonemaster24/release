﻿# MyDashboardUpdate.ps1
# Downloads the complete MyDashboard Google Drive folder as a
# Base64-encoded ZIP and extracts it recursively to C:\MyDashboard.

$ErrorActionPreference = "Stop"

$InstallRoot = "C:\MyDashboard"
$TempDir = Join-Path $InstallRoot "_update"
$ZipPath = Join-Path $TempDir "MyDashboard.zip"
$JsonPath = Join-Path $TempDir "response.json"
$LogPath = Join-Path $InstallRoot "MyDashboardUpdate.log"

$UpdateUrl = "https://script.google.com/macros/s/AKfycbw9EvpQLlX06IeynrWhSY3sy1YNHDp2Zq4wuJVoFSo6J9PC7j8TQqilA5u5EY1LWh0Z6w/exec"


function Log {
    param([string]$Message)

    Add-Content `
        -LiteralPath $LogPath `
        -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $Message"
}


try {

    # ------------------------------------------------------------
    # Prepare folders
    # ------------------------------------------------------------

    New-Item `
        -ItemType Directory `
        -Path $InstallRoot `
        -Force `
        | Out-Null

    New-Item `
        -ItemType Directory `
        -Path $TempDir `
        -Force `
        | Out-Null


    Log "Starting recursive update."

    Write-Host ""
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host "  MyDashboard Recursive Update" -ForegroundColor Cyan
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host ""

    Write-Host "Getting package information..." -ForegroundColor Cyan


    # ------------------------------------------------------------
    # Request JSON from Apps Script
    # ------------------------------------------------------------

    $requestUrl =
        $UpdateUrl +
        "?action=download&t=" +
        [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()


    $wc = New-Object System.Net.WebClient

    try {

        $wc.Headers["User-Agent"] = "Mozilla/5.0"
        $wc.Headers["Accept"] = "application/json"

        $responseText = $wc.DownloadString($requestUrl)

    }
    finally {

        $wc.Dispose()
    }


    if ([string]::IsNullOrWhiteSpace($responseText)) {

        throw "Google Apps Script returned an empty response."
    }


    # Remove possible BOM and whitespace.

    $responseText =
        $responseText.Trim([char]0xFEFF).Trim()


    Log "Response length: $($responseText.Length)"


    # Save response temporarily for diagnostics.

    Set-Content `
        -LiteralPath $JsonPath `
        -Value $responseText `
        -Encoding UTF8


    # ------------------------------------------------------------
    # Parse JSON
    # ------------------------------------------------------------

    try {

        $result = $responseText | ConvertFrom-Json

    }
    catch {

        Log "RAW RESPONSE: $responseText"

        throw `
            "Google Apps Script did not return valid JSON. " +
            "The response was saved to $JsonPath."
    }


    if (!$result.ok) {

        throw "Google Apps Script error: $($result.error)"
    }


    if ([string]::IsNullOrWhiteSpace($result.data)) {

        throw "Google Apps Script returned no ZIP data."
    }


    if ([string]::IsNullOrWhiteSpace($result.fileName)) {

        $result.fileName = "MyDashboard.zip"
    }


    Log "ZIP filename: $($result.fileName)"
    Log "ZIP size reported by Apps Script: $($result.size) bytes"
    Log "Base64 length: $($result.data.Length)"


    # ------------------------------------------------------------
    # Decode Base64
    # ------------------------------------------------------------

    Write-Host "Decoding MyDashboard.zip..." -ForegroundColor Cyan

    $zipBytes = [Convert]::FromBase64String($result.data)


    if ($zipBytes.Length -lt 22) {

        throw `
            "Decoded ZIP is too small: $($zipBytes.Length) bytes."
    }


    Log "Decoded ZIP size: $($zipBytes.Length) bytes"


    # ------------------------------------------------------------
    # Validate ZIP signature
    # ------------------------------------------------------------

    # Normal ZIP files begin with PK.
    # 50 4B 03 04 = standard ZIP local file header.
    # 50 4B 05 06 = empty ZIP.
    # 50 4B 07 08 = spanned ZIP.

    $isZip =
        (
            $zipBytes[0] -eq 0x50 -and
            $zipBytes[1] -eq 0x4B -and
            (
                (
                    $zipBytes[2] -eq 0x03 -and
                    $zipBytes[3] -eq 0x04
                ) -or
                (
                    $zipBytes[2] -eq 0x05 -and
                    $zipBytes[3] -eq 0x06
                ) -or
                (
                    $zipBytes[2] -eq 0x07 -and
                    $zipBytes[3] -eq 0x08
                )
            )
        )


    if (!$isZip) {

        $firstBytes =
            (($zipBytes |
                Select-Object -First 12 |
                ForEach-Object { $_.ToString("X2") }) -join " ")

        Log "Invalid ZIP signature. First bytes: $firstBytes"

        throw `
            "Decoded data is not a ZIP file. First bytes: $firstBytes"
    }


    # ------------------------------------------------------------
    # Save ZIP
    # ------------------------------------------------------------

    if (Test-Path -LiteralPath $ZipPath) {

        Remove-Item `
            -LiteralPath $ZipPath `
            -Force
    }


    [System.IO.File]::WriteAllBytes(
        $ZipPath,
        $zipBytes
    )


    $actualSize =
        (Get-Item -LiteralPath $ZipPath).Length


    Log "ZIP saved: $actualSize bytes"


    if ($actualSize -ne $zipBytes.Length) {

        throw "ZIP file size verification failed."
    }


    # ------------------------------------------------------------
    # Test ZIP before extracting
    # ------------------------------------------------------------

    Write-Host "Validating ZIP..." -ForegroundColor Cyan

    Add-Type -AssemblyName System.IO.Compression.FileSystem

    $zip = $null

    try {

        $zip =
            [System.IO.Compression.ZipFile]::OpenRead(
                $ZipPath
            )

        $entryCount = $zip.Entries.Count

        Log "ZIP validation successful. Entries: $entryCount"

    }
    finally {

        if ($null -ne $zip) {
            $zip.Dispose()
        }
    }


    if ($entryCount -eq 0) {

        throw "The ZIP contains no files."
    }


    # ------------------------------------------------------------
    # Extract recursively
    # ------------------------------------------------------------

    Write-Host ""
    Write-Host "Extracting recursively to C:\MyDashboard..." -ForegroundColor Cyan

    Log "Extracting package."

    Expand-Archive `
        -LiteralPath $ZipPath `
        -DestinationPath $InstallRoot `
        -Force


    # ------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------

    Remove-Item `
        -LiteralPath $ZipPath `
        -Force `
        -ErrorAction SilentlyContinue

    Remove-Item `
        -LiteralPath $JsonPath `
        -Force `
        -ErrorAction SilentlyContinue


    Log "Update completed successfully."


    Write-Host ""
    Write-Host "============================================" -ForegroundColor Green
    Write-Host " MyDashboard update completed successfully" -ForegroundColor Green
    Write-Host "============================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Files updated in:" -ForegroundColor Green
    Write-Host "C:\MyDashboard" -ForegroundColor Green
    Write-Host ""
    Write-Host "ZIP entries: $entryCount"
    Write-Host "ZIP size: $actualSize bytes"
    Write-Host ""


    exit 0

}
catch {

    $message = $_.Exception.Message

    Log "ERROR: $message"


    Write-Host ""
    Write-Host "============================================" -ForegroundColor Red
    Write-Host " MYDASHBOARD UPDATE FAILED" -ForegroundColor Red
    Write-Host "============================================" -ForegroundColor Red
    Write-Host ""
    Write-Host $message -ForegroundColor Red
    Write-Host ""
    Write-Host "Log file:" -ForegroundColor Yellow
    Write-Host $LogPath -ForegroundColor Yellow
    Write-Host ""


    exit 1
}
