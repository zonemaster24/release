MYDASHBOARD BASE64 RECURSIVE UPDATER
=====================================

Google Drive folder:
1rXGsXlDcVaPdT0OXtYDsFrzLH88FXKJk

Web App:
https://script.google.com/macros/s/AKfycbw9EvpQLlX06IeynrWhSY3sy1YNHDp2Zq4wuJVoFSo6J9PC7j8TQqilA5u5EY1LWh0Z6w/exec

FILES
-----
MyDashboardUpdate.gs
    Google Apps Script. Recursively reads the Drive folder,
    creates MyDashboard.zip, and returns the ZIP as Base64 JSON.

MyDashboardUpdate.ps1
    Calls the Web App, decodes the Base64 ZIP, validates the ZIP,
    and extracts it recursively to C:\MyDashboard.

MyDashboardProtocol.ps1
    Supports:
       mydashboard://setup
       mydashboard://idprinting
       mydashboard://deliverynote

Download-System-Scripts.cmd
    Manual test launcher.

INSTALL
-------
1. Put MyDashboardUpdate.gs into the Apps Script project.
2. Deploy/redeploy as a Web App.
3. It must be accessible to the Windows updater without an interactive
   Google login.
4. Copy MyDashboardUpdate.ps1 to C:\MyDashboard\
5. Copy MyDashboardProtocol.ps1 to C:\MyDashboard\
6. Copy Download-System-Scripts.cmd to C:\MyDashboard\

TEST
----
First run:

    C:\MyDashboard\Download-System-Scripts.cmd

Then test from Command Prompt:

    start "" "mydashboard://setup"

The updater:
- reads the Drive folder recursively
- includes files in subfolders
- creates a ZIP
- Base64 encodes the ZIP
- PowerShell decodes it
- validates the ZIP
- extracts to C:\MyDashboard
- overwrites existing files
- preserves unrelated local files
