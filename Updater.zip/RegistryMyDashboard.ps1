# ============================================================
# Register MyDashboard Protocol
# ============================================================

$InstallFolder = "C:\MyDashboard"

$Launcher = Join-Path $InstallFolder "MyDashboardLauncher.exe"

if (!(Test-Path -LiteralPath $Launcher)) {

    Write-Host ""
    Write-Host "ERROR:"
    Write-Host "MyDashboardLauncher.exe was not found:"
    Write-Host $Launcher
    Write-Host ""

    pause
    exit 1
}


# ============================================================
# REGISTRY PATH
# ============================================================

$ProtocolRoot =
    "HKCU:\Software\Classes\mydashboard"


# ============================================================
# REMOVE OLD REGISTRATION
# ============================================================

if (Test-Path -LiteralPath $ProtocolRoot) {

    Remove-Item `
        -LiteralPath $ProtocolRoot `
        -Recurse `
        -Force
}


# ============================================================
# CREATE PROTOCOL
# ============================================================

New-Item `
    -Path $ProtocolRoot `
    -Force |
    Out-Null


New-ItemProperty `
    -Path $ProtocolRoot `
    -Name "URL Protocol" `
    -Value "" `
    -PropertyType String `
    -Force |
    Out-Null


# ============================================================
# DEFAULT NAME
# ============================================================

Set-ItemProperty `
    -Path $ProtocolRoot `
    -Name "(default)" `
    -Value "URL:MyDashboard Protocol"


# ============================================================
# SHELL
# ============================================================

$CommandPath =
    "$ProtocolRoot\shell\open\command"


New-Item `
    -Path $CommandPath `
    -Force |
    Out-Null


# ============================================================
# COMMAND
# ============================================================
#
# %1 = mydashboard://studentid
#
# Windows passes the clicked URL to the launcher.
#
# ============================================================

$Command =
    '"' + $Launcher + '" "%1"'


Set-ItemProperty `
    -Path $CommandPath `
    -Name "(default)" `
    -Value $Command


# ============================================================
# DISPLAY RESULT
# ============================================================

Write-Host ""
Write-Host "============================================================"
Write-Host "MyDashboard protocol registered successfully."
Write-Host "============================================================"
Write-Host ""

Write-Host "Launcher:"
Write-Host $Launcher

Write-Host ""

Write-Host "Command:"
Write-Host $Command

Write-Host ""

Write-Host "Protocol:"
Write-Host "mydashboard://"

Write-Host ""
Write-Host "============================================================"
Write-Host ""

pause